﻿using System;
namespace FactorialCalculations
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Please Select 1 for factorial and 2 for Print the Number");
            var input = Console.ReadLine();           
            if (input == "1") 
            {
                Console.WriteLine("Please enter factorial value : ");
                bool isnumber = int.TryParse(Console.ReadLine(), out int n);
                if (n < 0)
                {
                    Console.WriteLine("Please do not pass negative value.");
                    return;
                }
                else if (!isnumber)
                {
                    Console.WriteLine("Please pass integer value.");
                    return;
                }

                Factorial fact = new Factorial();
                var output = fact.Getfactorial(n);
                Console.Write($"Factorial of {n} is:{output}");
            }
            else if(input == "2")
            {
                Print print = new Print();
                print.PrintNumber();
            }
            else
            {
                Console.WriteLine("Please Provide the valid input");             
            }
        }
    }
}

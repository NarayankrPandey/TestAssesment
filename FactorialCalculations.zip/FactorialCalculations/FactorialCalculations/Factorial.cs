﻿namespace FactorialCalculations
{
    public class Factorial
    {
        /// <summary>
        /// This method is used to calculate the factorial value of input number.
        /// </summary>
        /// <param name="fact"></param>
        /// <returns></returns>
        public int Getfactorial(int fact)
        {
            if (fact == 0)
            {
                return 1;
            }
            return fact * Getfactorial(fact - 1);

        }
    }
}
    



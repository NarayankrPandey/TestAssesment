﻿using System;
namespace FactorialCalculations
{
    class Print
    {
        /// <summary>
        /// This methos is used to Print the Number from 1 to 100 With fizz, buzz and fizzbuzz.
        /// </summary>
        public void PrintNumber()
        {
            for (int i = 1; i < 101; i++)
            {
                if (i % 3 == 0 & i % 5 == 0)
                {
                    Console.WriteLine("fizzbuzz");
                }
                else if (i % 3 == 0)
                {
                    Console.WriteLine("fizz");
                }
                else if (i % 5 == 0)
                {
                    Console.WriteLine("buzz");
                }
                else
                {
                    Console.WriteLine(i);
                }
            }
        }
    }
}

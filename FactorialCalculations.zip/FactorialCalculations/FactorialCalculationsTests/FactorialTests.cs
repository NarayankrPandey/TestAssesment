﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using FactorialCalculations;

namespace FactorialCalculationsTests
{
    [TestClass()]
    public class FactorialTests
    {
        [TestMethod()]
        
        public void GetfactorialTest()
        {
            Factorial fact = new Factorial();
            int result = fact.Getfactorial(3);
            Assert.AreEqual(6, result);           
        }
    }
}